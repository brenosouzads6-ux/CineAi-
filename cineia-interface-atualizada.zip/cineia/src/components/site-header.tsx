import { Link, useRouterState } from "@tanstack/react-router";
import {
  Bell, Compass, Film, Heart, Home, Search, Settings, UserCircle2, Clapperboard,
} from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Início", icon: Home },
  { to: "/filmes", label: "Explorar", icon: Compass },
  { to: "/series", label: "Séries", icon: Film },
  { to: "/animes", label: "Animes", icon: Clapperboard },
  { to: "/desenhos", label: "Desenhos", icon: Heart },
] as const;

export function SiteHeader() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <>
      <aside className="cine-sidebar">
        <Link to="/" className="cine-brand"><span>CINE</span>AI</Link>
        <p className="sidebar-caption">MENU PRINCIPAL</p>
        <nav className="sidebar-nav" aria-label="Navegação principal">
          {NAV.map(({ to, label, icon: Icon }) => (
            <Link key={to} to={to} className={cn("sidebar-link", pathname === to && "active")}>
              <Icon size={19} strokeWidth={2.1} /><span>{label}</span>
            </Link>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <Link to="/admin" className={cn("sidebar-link", pathname === "/admin" && "active")}>
            <Settings size={19} /><span>Painel</span>
          </Link>
          <div className="sidebar-profile">
            <UserCircle2 size={30} />
            <div><strong>Meu perfil</strong><small>Bem-vindo ao CineAI</small></div>
          </div>
        </div>
      </aside>
      <header className="cine-topbar">
        <div className="mobile-brand"><Link to="/">CINE<span>AI</span></Link></div>
        <div className="top-search"><Search size={18}/><input aria-label="Buscar no catálogo" placeholder="Buscar filmes, séries, animes..."/></div>
        <div className="top-actions">
          <button className="icon-action" aria-label="Notificações"><Bell size={19}/><i/></button>
          <button className="profile-pill"><span className="profile-avatar"><UserCircle2 size={22}/></span><span><b>Meu perfil</b><small>Plano gratuito</small></span></button>
        </div>
      </header>
    </>
  );
}
